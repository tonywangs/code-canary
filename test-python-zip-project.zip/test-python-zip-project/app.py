from flask import Flask, jsonify
import requests
import urllib3

app = Flask(__name__)

@app.route('/')
def hello():
    return 'Hello from Python ZIP test project!'

@app.route('/api/data')
def get_data():
    try:
        response = requests.get('https://api.example.com/data')
        return jsonify(response.json())
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000) 