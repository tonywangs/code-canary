# Python Test ZIP Project

This is a Python test project for ZIP repository scanning with known vulnerabilities.

## Dependencies

- requests==2.25.1 (has CVE-2023-32681 - Medium severity)
- urllib3==1.26.5 (has CVE-2021-33503 - High severity ReDoS)
- flask==2.0.1 (current version)
- django==3.2.0 (current version)

## Usage

```bash
pip install -r requirements.txt
python app.py
```

This project is designed to test the ZIP repository scanning functionality of Dependency Canary with Python dependencies. 