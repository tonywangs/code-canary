const express = require('express');
const axios = require('axios');
const _ = require('lodash');
const moment = require('moment');

const app = express();
const port = 3000;

app.get('/', (req, res) => {
  res.send('Hello from test ZIP project!');
});

app.get('/api/data', async (req, res) => {
  try {
    const response = await axios.get('https://api.example.com/data');
    const processedData = _.map(response.data, item => ({
      ...item,
      timestamp: moment().format()
    }));
    res.json(processedData);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(port, () => {
  console.log(`Test ZIP project running on port ${port}`);
}); 