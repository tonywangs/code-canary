# Test ZIP Project

This is a test project for ZIP repository scanning with known vulnerabilities.

## Dependencies

- axios@0.21.1 (has CVE-2021-3749 - Critical SSRF vulnerability)
- lodash@4.17.19 (has CVE-2020-8203 - High severity prototype pollution)
- express@4.18.2 (current version)
- moment@2.29.4 (current version)

## Usage

```bash
npm install
npm start
```

This project is designed to test the ZIP repository scanning functionality of Dependency Canary. 